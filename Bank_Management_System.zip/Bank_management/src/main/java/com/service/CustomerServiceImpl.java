package com.service;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.entity.Customer;
import com.repository.CustomerRepository;

@Service
public class CustomerServiceImpl implements CustomerService{
	
	@Autowired
	CustomerRepository customerRepo;

	@Override
	public boolean registerCustmore(Customer customer) {
		// TODO Auto-generated method stub
		try {
			customerRepo.save(customer);
		return true;
		}catch (Exception e){
			return false;
		}
	}

	@Override
	public Customer loginCustomer(String adharno, String password) {
		// TODO Auto-generated method stub
		Customer validuser=customerRepo.findByAdharno(adharno);
		if(validuser!=null && validuser.getPassword().equals(password)) {
			return validuser;
		}
		return null;
		
	}
	
}
