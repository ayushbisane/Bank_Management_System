package com.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.entity.Admin;
import com.repository.AdminRepository;

@Service
public class AdminSeviceImpl implements AdminService{
	
	@Autowired
	AdminRepository adminRepo;
	
	public boolean registerAdmin(Admin admin) {
		// TODO Auto-generated method stub
		try {
			adminRepo.save(admin);
		return true;
		}catch(Exception e) {
			return false;
		}
	}

	public Admin loginAdmin(String name, String password) {
		// TODO Auto-generated method stub
		Admin validadmin=adminRepo.findByAdminname(name);
		if(validadmin!=null && validadmin.getPassword().equals(password)) {
			return validadmin;
		}
		return null;
	}

}
