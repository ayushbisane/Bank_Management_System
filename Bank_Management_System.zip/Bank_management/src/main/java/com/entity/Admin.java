package com.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "Amintbl")
public class Admin {
	@Id
	@Column(unique = true)
	private long admin_id;
	@Column
	private String adminname;
	@Column(unique = true)
	private long contact;
	@Column
	private String password;
	@Column(unique = true)
	private String adharno;

	public long getAdmin_id() {
		return admin_id;
	}

	public void setAdmin_id(long admin_id) {
		this.admin_id = admin_id;
	}

	public String getAdminname() {
		return adminname;
	}

	public void setAdminname(String adminname) {
		this.adminname = adminname;
	}

	public long getContact() {
		return contact;
	}

	public void setContact(long contact) {
		this.contact = contact;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getAdharno() {
		return adharno;
	}

	public void setAdharno(String adharno) {
		this.adharno = adharno;
	}

	@Override
	public String toString() {
		return "Admin [admin_id=" + admin_id + ", adminname=" + adminname + ", contact=" + contact + ", password="
				+ password + ", adharno=" + adharno + "]";
	}

	public Admin(long admin_id, String adminname, long contact, String password, String adharno) {
		super();
		this.admin_id = admin_id;
		this.adminname = adminname;
		this.contact = contact;
		this.password = password;
		this.adharno = adharno;
	}

	public Admin() {
		super();
		// TODO Auto-generated constructor stub
	}

}
